import java.util.Random;
public class for_1 {
    public static void main(String[] args){
    // 반복문 처리의 핵심
    // 예) 1 ~5 정수를 전부 더하고 싶다
    // for문 없는 인생 하드모드
    int sum = 0 ;
    sum = sum + 1;
    sum = sum + 2;
    sum = sum + 3;
    sum = sum + 4;
    sum = sum + 5;
    System.out.println(sum);
    // 결과를 담을 정수자료형 sum2를 변수를 선언해서 0을 담습니다.
    int sum2 = 0;
    // for문 있는 인생 이지모드
    for (int i =1; i<6; i++) {
        sum2 = sum2 + i;
        // 중간과정을 보기위해 중간결과도 출력~
        System.out.println(sum2);
    }
    System.out.println(sum2);

    // for문 퀴즈: 1~45사이의 무작위 당첨번호 6개를 뽑아보세요
    // 아래는 개별 당첨번호입니다.
    // int lotto = (int) (Math.random() *45) + 1;

    // Random random = new Random();

    // for 문의 구성요소:
    // 1. 시작지점 (보통은 i라고 쓰는데, 변수 이름만 일관되면 뭐가오든 상관없음)
    // 남들쓰는 이름을 쓰는 이유는? 협업때 다른사람 잘 알아보도록 한다
    // 시작지점과 끝은 정수형태로 와야죠
    // 2. 끝지점(반복횟수)
    // for 문은 반복횟수를 기록하는것이라 시작값이 반드시 1일 이유없음
    // 코딩의 목적에 맞게 for문의 범위를 지정해 주면 됩니다.
    // for문의 범위가 바르지 못하면 암것도 안된다
    // 다른 에러와 다르게 for문의 범위를 잘못 설정하면
    // 컴퓨터가 에러를 잡지 못하는 경우가 생긴다.
    int i = 1;
    for (i = 1; i < 7; i++) {
        int lotto = (int) (Math.random() *45) + 1;
        System.out.println("로또번호는" + i + ":" + lotto);
    }
    // i는 for 문 내에서 생생된 지역변수라서 
    // for문을 벗어나면 사용이 안됩니다. 
    System.out.println( i );
    // 반복문 종료 후에도 반복변수 i를 쓰고 싶다면
    // for문 바로 위에 변수를 선언해서 for문 밖에서 
    // 변수가 선언되도록 합니다.
    }
}
