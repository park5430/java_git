import java.util.Scanner;

public class for_4 {
    public static void main(String[] args) {
        // 문제: 두개의 정수값을 사용자에게 입력받아서
        // 시작값부터 끝 값까지 합계를 출력하세요
        // 예) 시작값:1 끝값:100 합계:5050
        // "xxx부터 yyy까지 합은 000입니다" 이런식으로 나오게 해주세요

        // 1. scanner 기능으로 사용자 입력을 받도록 해주세요
        // 2. for문으로 시작과 끝까지 수를 더하도록 해주세요
        // 3. 입력받은 값이 for문의 시작과 끝이 되도록 변수를 연결해 주세요

        // 시스템에서 입력받은 값을 Scanner 객체에 저장해서 쓰겠습니다
        // Scanner 객체는 입력값이 몇개이든 한번만 선언하면 됩니다.
        // Scanner 객체 안에 nextInt라는 기능을 쓰려고 선언한겁니다. 
        // 입력결과는 각각 다른 변수에 저장되니까 괜찮습니다.
        Scanner scanner = new Scanner(System.in);
        // 유저에게 값을 입력하라는 메세지를 출력해 줍니다.
        System.out.print("시작값을 입력해 주세요: ");
        // 유저가 어떤 값을 입력하면 정수형태로 받아서 start변수에 저장합니다.
        int start = scanner.nextInt();
        // 유저에게 끝값을 입력하라는 메세지를 출력해 줍니다.
        System.out.print("끝값을 입력해 주세요: ");
        // 유저가 끝값을 입력하면 정수형태로 받아서 end변수에 저장합니다.
        int end = scanner.nextInt();
        // for문 밖에서 결과를 조회하기 위해 
        // 합계를 저장할 변수를 for문 밖에서 만듭니다.
        int sum = 0;
        // 숫자를 더할 for문을 만듭니다. 저장된 값을 변수로 꺼내씁니다
        for (int i = start; i <= end; i++) {
            // 현재 합 결과에 순서대로 숫자를 더해 나간다는 의미입니다
            sum = sum + i;
        }
        System.out.println(start+ "부터" + end + "까지의 합은" + sum + "입니다");
    }
}
