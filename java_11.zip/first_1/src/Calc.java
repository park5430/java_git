// 덧셈 로직이 들어간 계산기 코드입니다.
class calculator {
    static int result = 0;

    static int add(int num) {
        result += num;
        return result;
    }
}

public class Calc {
    public static void main(String[] args) {
        System.out.println(calculator.add(3));
        System.out.println(calculator.add(4));
    }
}
