
// 내 파일이름과 동일하게 클래스 선언 (대소문자를 구분)
public class App {
    public static void main(String[] args) throws Exception {
        // 아래서 부터가 코드의 실제 본문입니다.
        // system.out은 시스템에서 내보낸다는 말이고 
        // println은 메세지를 출력하라는 말입니다.
        System.out.println("Hello, World!");
    }
}
