public class example_1 {
    public static void main(String[] args) {
        // 정수 형태의 값을 가지게 될 value 라는 이름의 변수선언
        int value = 5;

        // 연산 결과를 변수 result의 값으로 대입
        int result = value + 10;
        // 계산 결과가 담긴 result 변수를 출력
        System.out.println(result);
    }
}
