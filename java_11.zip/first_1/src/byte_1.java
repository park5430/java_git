public class byte_1 {
    public static void main(String[] args) {
        // 정수 크기에 맞는 데이터가 입력 되어야 한다.
        byte var1 = 100;
        byte var2 = 127;
        // 21.47억이 넘는 큰 수는 long이라고 
        // 데이터 타입을 정해줘야한다. 근데 이 때 숫자 뒤에 
        // 대문자 L혹은 소문자 l을 포함시켜야 한다.
        // 자바의 컴파일러는 숫자를 int로 인식하기 때문
        long var3 = 10000000000L;
        // 문자열에서 문자 데이터를 작은따옴표로 감싼 것을 문자 리터럴이라 합니다.
        // 리터럴의 의미는 사람이 알아듣게 써놓은 문자입니다.
        // 예를 들면 숫자리터럴 3 이 말은 그냥 숫자3으로써서 사람이
        // 알아보게 쓴거구나 이해하시면 됩니다,.
        // 사람이 이해못하게 3으로 쓴거는 2진수 11 이겠죠?
        // 2*1 + 1*1
        // 문자 리터럴은 유니코드로 변환되어 저장되는데
        // 유니코드란 세계의 언어를 0 ~ 65535 숫자를 부여하여
        // 세계 언어의 알파벳을 숫자로 표현하는 방법입니다.
        // 밑에를 출력하면 A에 해당하는 숫자인 65가 출력됩니다.
        char var6 = 'A';
        char var7 = 65;
        System.out.println(var6);
        System.out.println(var7);
        // float는 소수점 7자리
        // double은 소수점 15자리까지 표현 가능
        float var8 = 0.123456789012f;
        double var9 = 0.123456789012;
        System.out.println(var8);
        System.out.println(var9);
        // 이제는 언어데이터 즉, 문자열 데이터에 대해 이야기 하겠습니다
        // char로 표현 가능하고 String으로도 표현 가능합니다
        // 주의사항은 char은 작은따옴표만 써야하고 char var6 = 'A';
        // String은 큰 따옴표만 써야 합니다. String var6 = "A";
// 이유는 char는 문자에 대응하는 숫자를 표현한다고 그랬죠?
// 문자에 대응하는 숫자로 표현할 때 작은따옴표를 써야 이러한 변환가능
// 큰따옴표를 쓰면 변환이 불가능 합니다.
// 그래서 숫자와 문자를 변환하는 데이터는 char '' 이렇게 나타내고
// 문자데이터 그 자체로만 쓸거면 String ""이렇게 나타냅니다.
char var11 = 'A';
String var12 = "r";

// 이스케이프 문자: 특정 문자를 포함하거나 출력에 영향을 미친다.
// 예를들어 문장에 \n 포함하면 출력시 한줄 띄어진다.

String name = "이젠컴터학원";
String name2 = "이젠\n컴터학원"; //  \n는 줄바꾸기
String name3 = "이젠\t컴터학원"; //  \t는 탭 (4칸띄기)
String name4 = "이젠\"컴터\"학원"; // 백슬래시 바로뒤에 글자 붙이면 큰 따옴표 처리가능

System.out.println(name);
System.out.println(name2);
System.out.println(name3);
System.out.println(name4);

// 자동 타입변환:
// char, int, short, byte 여러가지 변수가 있는데요,
// 만약에 서로다른 변수 타입이 계산된다면 어떨까요?
// 컴퓨터는 각기 다른 정수데이터의 계산 결과가 
// 미래에 뭐가 나올지 모른다는 생각에 
// 더 큰수가 허용되는 결과로 정수타입을 "자동"으로 바꾼다
byte aaa = 10;
short bbb = 1111;

int ccc = aaa + bbb;
System.out.println(ccc);
// 음수를 허용하지 않는 char 데이터 셋에 
// 음수가 나올 수 있는 byte 타입 소속 값을 넣으려 하면 에러난다.
// 지금 변수에 저장된 값이 char 타입에 허용범위에 있어도
// byte로 선언된 결과값이 미래에 어떻게 될지 모른단 생각에
// 컴퓨터는 오류를 일으키고 작업을 수행하지 않는다~
byte byte1 = 67;
short charchar = byte1;

// 만약에 내가 모든 결과값 데이터 범위를 아니까
// 더 작은 데이터셋에 변수를 담고 싶다면?
// 강제 타입변환

// 작은 허용범위 타입 = (작은 허용범위 타입) 큰 허용범위 타입
int value2 = 10;
byte bbbb = (byte) value2; // 강제 타입변환

// 강제 타입변환시 주의사항
// 소수점은 정수변환시 소수점은 짤린다 (데이터 손실가능성)
double dddd = 3.14;
int eeeee = (int) dddd;
System.out.println(eeeee);

// 오버플로우 언더플로우
// 오버플로우=타입이 허용하는 최대값을 벗어나는 것
// 언더플로우=타입이 허용하는 최소값을 벗어나는 것

byte value88 = 127; // byte타입의 최대값 부여
value88++; // 강제로 1더함
System.out.println(value88);

byte value99 = -128; // byte타입의 최소값 부여
value99--; // 강제로 1뺌
System.out.println(value99);
// 테스트 하지않은 다른 정수 타입도 같은 문제가 발생한다.

// 백엔드 언어의 고질병: 소수점 계산 문제점
// 자바가 아닌 백엔드 언어라고 말한 이유는?
// 파이썬에서도 같은 문제가 있어요 ㅋㅋ

int apple =1;
double vvv = 0.1;
int numnum = 7;

double results = apple - numnum * vvv;
System.out.println(results);
// 정확한 계산은 정수계산을 하시고 원하는 소수점으로 나눠주세요
// 소수점 계산 고질병 예시2
// 변수 jjj & kkk 는 같은 0.1을 저장한 건데 
// 두 값이 같지않다는 메세지가 나오고 있다.
float kkk = 0.1f;
double jjj = 0.1;
System.out.println(kkk == jjj);


    }
}
