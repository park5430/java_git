public class while_1 {
    public static void main(String[] args) {
        // // 1 ~3 까지 출력
        // for (int i = 1; i <= 3; i++) {
        //     System.out.println("i = " + i);
        // }

        int i = 1;
        // while 문은 괄호안 조건을 조사해서 괄호안 조건이 맞으면 반복
        // while (i <= 3) {
        //     System.out.println("i = " + i);
        //     i++;
        // }
        // 무한반복 예제
        // 강제로 나올 때 break 사용
        // break를 잘못쓰면 무한반복할 수 있으니 
        // while문 조건안에 true라고 쓰는건 비추
        while (true) {
            System.out.println("i = " + i);
            i++;
            if (i ==3) {
                System.out.println("i = " + i);
                System.out.print("빠져나왔다");
                break;
                
            }
        }
        // do-while 문 예제
        // do while문은 일단 do 안에 조건을 실행하고 while문으로 반복여부를 판단
        int j = 1;
        do {
            System.out.println("j = " + j);
            j++;
        } while (j < 3);
        System.out.println("j = " + j);
        System.out.print("빠져나왔다");
        // while문에서 true를 변수처리하는 방법
        // break안쓰는법 (boolean 타입변수를 통해서 참거짓 변수화)
        int k = 1;
        boolean run = true;
        while (run) {
            System.out.println("i = " + k);
            k++;
            if (k ==3) {
                System.out.println("i = " + k);
                System.out.print("빠져나왔다");
                run = false;
            }
        }
    }
}
