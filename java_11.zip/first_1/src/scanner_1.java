// java.util 패키지에 소속된 scanner클래스 가져오기
// 사용자 입력값 가져오기
import java.util.Scanner;

public class scanner_1 {
    public static void main(String[] args) {
        // scanner 클래스를 가져와서 사용자의 입력값을 받아올 수 있다.
        // scanner1 이라는 이름의 Scanner 객체선언
        // System.in으로 받은 사용자의 입력값을 변수에 저장
        // 예를 들어, "자바기초"라고 사용자가 타이핑 하면 (System.in)
        // 그 데이터를 컴퓨터가 스캔해서 스캔된 데이터를 scanner1
        // 이름의 변수에 저장한다
        Scanner scanner1 = new Scanner(System.in);
        // 사용자가 뭘 해야할지를 가르쳐주는 출력문이다
        // 사용자에게 숫자를 입력해달라고 요청하는 구문 출력
        System.out.println("숫자를 입력하세요");
        // 사용자가 입력한 숫자를 받아서 num2변수에 저장
        int num2 = scanner1.nextInt();
        // 사용자가 입력한 숫자를 출력하기
        System.out.println(num2);
        // 이번엔 이름을 입력하라고 알려준다
        System.out.println("이름을 입력하세요");
        // 사용자가 입력한 이름을 받아서 name변수에 저장
        // 이름을 받아오니까 문자열데이터 즉, String을 쓰고
        // 정수가 아니니까 nextInt 말고 next이다.
        String name = scanner1.next();
        // 사용자가 입력한 이름을 출력하기
        System.out.println(name);
    }
}
