public class review_1 {
    public static void main(String[] args) {
        // 두개의 변수를 동시에 선언할 때 ,를 사용하면 된다
        int num1 = 10, num2 = 5;
        // 의도한 15가 아닌 105가 나온 이유는
        // 문자데이터와 숫자데이터를 + 로 연결하면
        // 모든 데이터를 문자 처리해서 옆에 붙여서 출력한다.
        // 그래서 10과 5가 더해지지 못하고
        // "10" 과 "5"가 숫자가 아닌 문자 데이터 취급을 받는다.
        // 그래서 "덧셈결과" "10" "5"라는 문자 데이터가 나란히 출력
        // 이 문제를 해결하려면 숫자 계산할 결과를 괄호쳐서 미리계산
        System.out.println("덧셈결과: " + num1 + num2);
        System.out.println("덧셈결과: " + (num1 + num2));

        // 연산자 정리
        // 1) 일반 연산자 (+ - * /) %
        // %는 나눗셈의 나머지 입니다. 10 나누기 5의 나머지는 0  
        System.out.println("나머지결과: " + (num1 % num2));
        // 2) 비교연산자 <, >, >=, <= 
        System.out.println(10 > 5); // 참
        System.out.println(10 < 5); // 거짓
        // 부울변수의 선언 (55는 40보다 작다고 했으니 거짓이다)
        boolean result = 55 < 40;
        System.out.println(result); // 거짓

        // 대입연산자 표기법
        // 처음에 10, 5로 시작했는데 num1에 num2만큼 더해줌
        num1 += num2; // num1 = num1 + num2;
        System.out.println("num1: " + num1 + " num2: " + num2);
        // 만약에 한번 더 더해준다면? --> num1은 20이 된다
        num1 += num2; // num1 = num1 + num2;
        System.out.println("num1: " + num1 + " num2: " + num2);
        // 숫자 빼는 표기법 참고 --> num1은 도로 15가 된다
        num1 -= num2; // num1 = num1 - num2;
		System.out.println("num1: " + num1 + " num2: " + num2);
        // 곱하는 표기법 --> num1은 15 * 5 = 75
        num1 *= num2; // num1 = num1 * num2
		System.out.println("num1: " + num1 + " num2: " + num2);
        // 나누는 표기법 --> num1은 75 / 5 = 15
        num1 /= num2; // num1 = num1 / num2
		System.out.println("num1: " + num1 + " num2: " + num2);

        // for문에서 쓴 ++, --의 이름은 증감 연산자 입니다.
    }
}
