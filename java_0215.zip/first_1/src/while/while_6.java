import java.util.Scanner;
public class while_6 {
    public static void main(String[] args) {
    // 은행 프로그램 만들기    
    //System.out.println("-------------------------------------");
    //System.out.println("1.예금 | 2.출금 | 3.잔고 | 4.종료");
    //System.out.println("-------------------------------------");
    // 예를 들어 1번을 입력하면 예금 액을 유저에게 입력받아서 잔고에 더함
    // 2번을 입력하면 유저에게 입력받은 금액만큼 잔고를 뺌
    // 3번은 잔고조회
    // 4번을 입력하면 프로그램에서 빠져 나오기
    boolean run = true;
    int deposit = 0; // 입금액
    int withdraw = 0; // 출금액
    int select = 0; // 기능선택
    int balance = 0; // 잔고
    Scanner scan = new Scanner(System.in); // Scanner 클래스타입의 변수 scan
    while (run) {
        System.out.println("-------------------------------------");
        System.out.println("1.예금 | 2.출금 | 3.잔고 | 4.종료");
        System.out.println("-------------------------------------");
        System.out.print("선택> ");
        select = scan.nextInt();
        if (select == 1) {
            // 예금액을 유저 입력값을 받아서 잔고에 더해주세요
            System.out.print("예금액을 입력하여 주시기 바랍니다>");
            deposit = scan.nextInt();
            balance = balance + deposit;
            System.out.print("입금이 완료되었습니다. 잔액은 "+balance);
        }
        else if (select == 2) {
            // 출금액을 받아서 잔고에 빼주세요
            System.out.print("출금액>");
            withdraw = scan.nextInt();
            if (withdraw > balance) {
                System.out.print("잔고가 부족해여...");
            }
            else {
                // 잔고가 부족하지 않은 경우에 한해서 뺄셈 계산
                balance = balance - withdraw;
                System.out.print("출금이 완료되었습니다. 잔액은 "+ balance);
            }
            // 여기안에 if문 달아서 출금액이 잔고보다 크면 인출 안되게해주세요
        }
        else if (select == 3) {
            // 현재 잔고를 출력해 주세요
            System.out.print("현재 잔액은 "+balance);
        }
        else if (select == 4) {
            run = false;
            System.out.print("종료합니다. 잔액은 "+ balance);
            // while문에서 탈출시켜 주시고 종료 메세지를 써주세요
        }
    }
    }
}
