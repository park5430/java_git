public class while_2 {
    public static void main(String[] args) {
        // while문 써서 1+2+3+4+5+6+7+8+9+10=55 출력해 보세요
        // 초기 변수 선언
        int i = 1, sum = 0;
        // for문과 달리 while은 순서에 해당하는 변수는 미리 선언해야한다.
        while (i <= 10) {
            sum = sum + i;
            if (i <10) {
                System.out.print(i + "+");
            }
            else {
                System.out.print(i + "=");
            }
            i++;
        }
        System.out.print(sum);
    }
}
