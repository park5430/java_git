public class while_5 {
    public static void main(String[] args) {
        /**
         * 1 + (-2) + 3 + (-4) + 5 + (-6) ~~~
         * 처럼 계산을 했을 때 합계가 100이 됐을 때의 숫자의 횟수를 출력
         * 정답 : 199  (숫자의 합과 숫자의 횟수 두가지를 세고 있어야 함)
         * 합계용 변수, 횟수용 변수, +- 부호용 변수
         */
        // 합계용 변수
        int sum = 0;
        // 1씩 더해 나가는 변수 1,2,3,4,5~~
        int count = 1;
        // 부호가 적용된 변수 1, -2, 3, -4, 5, -6~~
        int num = 0;
        // 홀짝 부호용 변수
        int s = 1;
        // while문 통제 부울변수
        boolean run = true;
        while(run) {
            sum = sum + num;
            if (sum>=100) {
            run = false;
            }
            else {
            num = s * count;
            s = -s;
            count++;
            }
        }
        System.out.println("num = " + num);
        System.out.println("sum = " + sum);        
    }
}
