import java.util.Scanner;
public class while_4 {
    public static void main(String[] args) {
        /**
         * random() 메서드를 이용해서 1~100 사이의 숫자를 하나 만들고
         * 반복문 안에서 해당 숫자를 맞출 때까지 계속 숫자를 입력받도록 하고
         * 숫자를 맞추면 종료하고 몇 번만에 맞췄는지를 출력해줌
         * 만약에 입력값 < 정답 --> " 더 큰수를 입력해 주세요"
         * 만약에 입력값 > 정답 --> " 더 작은수를 입력해 주세요"
         * if문을 통해 정답을 찍을 수 있는 힌트 제공
         */
        // 인풋값을 받을 수 있게 scanner 활성화 & while문 통제를 위한 부울변수 선언
        Scanner scanner = new Scanner(System.in);
        int input = 0;
        int count = 0;
        boolean run = true;
        // 1부터 100 사이 정수 무작위 생성 (주의: while문 안에 선언하면 안됨)
        // while문 밖에서 선언해야 중간에 결과 안바뀜
        int answer = (int) (Math.random() * 100) +1;
        while (run) {
            // 정답을 맞출 때까지 유저에게 입력값을 받아야 하므로 
            // 입력값을 받는 로직은 while문 내부에 있어야 합니다.
            System.out.print("숫자를 입력하세요: ");
            input = scanner.nextInt();
            // 입력값을 입력받은 횟수를 더해줘야 합니다.
            count++;
            if (input > answer){
                System.out.print("더 작은값을 입력하세요: ");
            }
           else if(input < answer) {
                System.out.print("더 큰값을 입력하세요: ");
           }
           else {
            System.out.print("정답입니다 ");
            System.out.print("시도횟수는 " + count + "회입니다.");
            // 정답을 맞춘경우 반드시 while문에서 나와야 하니 아래코드필요
            run = false;
           }
        }
    }
}
