import java.util.Scanner;

public class switch_2 {
    public static void main(String[] args) {
        // 사용자에게 4개 영단어 중 하나를 인풋으로 받을 것
        // desk(책상), chair(의자), monitor(모니터), mouse(마우스)
        // 프로그램을 실행하면 위 네 단어 중 하나를 입력하면 한국뜻출력
        // 저 중에 없는 단어 입력하면 사전에 없는 단어라고 출력
        // 스캐너 기능 활성화 부터 단어 데이터를 받기까지 입니다
        // 주의사항은 scanner.next(); 여기서 nextInt가 아니죠 ^^
        Scanner scanner = new Scanner(System.in);
        System.out.print("단어를 입력하세요: ");
        String word = scanner.next();

        switch (word) {
            case "desk":
                System.out.println("책상입니다.");
                break;
            case "chair":
                System.out.println("의자입니다.");
                break;
            case "monitor":
                System.out.println("모니터입니다.");
                break;
            case "mouse":
                System.out.println("마우스입니다.");
                break;
            default:
                System.out.println("사전에 없는 단어입니다.");
                break;
        }
    }
}
