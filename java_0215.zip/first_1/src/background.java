// public: 누구나 이 메서드에 접근 가능하다 private 이라고 하면 안됨
// class: 자바는 객체지향 언어인데 객체지향 명령어의 설계도, 지도가 클래스이다.
// static: 꼭 클래스 내부 변수가(인스턴스) 없어도 실행할 수 있다는 말이다 
// void: 함수(메서드)의 리턴값이 없다는 의미 (void라는 뜻이 텅 비었다는 말이기 때문에)

// background라는 파일은 누구나 접근 가능한 클래스이다.
public class background {
    // 공개 가능한, 변수가 없어도 되는, 외부에 전달할 리턴값이 없는 함수입니다.
    // String[]: 문자형 배열 자료형
    // arg: 자료형의 변수명이다
    public static void main(String[] args) {

    }
}
