import java.util.Scanner;

public class if_4 {
    public static void main(String[] args) {
    // 중첩 if문을 적용한 학점 출력을 해주세요. 100점을 초과하거나 
    // 0점 미만의 점수를 입력하면 '입력범위를 초과하였습니다.' 
    // 출력 0~100 점 사이의 값을 입력했다면 앞의 예제에서 했던 
    // A ~ F 학점 출력을 진행함. 단, 각 조건마다 학점값을 출력하는 것이 
    // 아니라 학점 출력을 위한 print 문장은 한번만 사용 
// 사용자의 점수 입력을 받는 코드를 완성하였습니다.
		Scanner scanner = new Scanner(System.in);
		System.out.print("점수: ");
		int score = scanner.nextInt();

// 문자열 성적을 담을 grade변수 선언
        String grade = "";
    //     if (0<=score && score<=100) {
    //         if (score >= 90) {
    //             grade = "A";
    //         }
    //         else if (score >= 80) {
    //             grade = "B";
    //         }
    //         else if (score >= 70) {
    //             grade = "C";
    //         }
    //         else if (score >= 60) {
    //             grade = "D";
    //         }
    //         else {
    //             grade = "F";
    //         }
    // }
    // // 0미만 100초과 시 입력범위 초과했다고 경고하기
    // else {
    //     System.out.println("입력범위를 초과하였습니다.");
    // }
    // // 최종학점 출력해 주기
    // System.out.println("학점은 " + grade + "입니다.");
    // 별해 (삼항 연산자)

grade = (0<=score && score<=100) ? 
(score >= 90 ? "a" : (score >=80 ? "b" : (score >= 70 ? "c" : 
(score >= 60 ? "d" : "f")))) : 
("입력범위를 초과하였습니다");
System.out.println("학점은 " + grade + "입니다.");
}
}