import java.util.Scanner;
public class if_7 {
    public static void main(String[] args) {
        // 서로 다른 정수 3개를 입력받아서 가장 큰 정수 출력하기 
        // (같은 숫자는 입력하지 않는다고 가정) 입력 
        // 예 첫번째숫자: 두번째숫자: 세번째숫자:
        // 출력 예 가장 큰 숫자는 00 입니다.

        // Scanner 기능의 활성화
        Scanner scan = new Scanner(System.in);
        System.out.print("첫번째 숫자 : ");
        // 입력받은 숫자를 num1 변수에 저장
        int num1 = scan.nextInt();
        // 두번째 숫자를 입력하라고 메세지 출력
        System.out.print("두번째 숫자 : ");
        // 입력받은 숫자를 num2 변수에 저장
        int num2 = scan.nextInt();
        // 세번째 숫자를 입력하라고 메세지 출력
        System.out.print("세번째 숫자 : ");
        // 입력받은 숫자를 num2 변수에 저장
        int num3 = scan.nextInt();

        // 입력받은 세 숫자를 비교해서 최대값 찾는 if절 완성
        // num1이 제일 큰 경우를 설정
        // if ( num1 > num2 && num1 > num3) {
        //     System.out.print("가장 큰 수는 "+num1);
        // }
        // else if ( num2 > num1 && num2 > num3) {
        //     System.out.print("가장 큰 수는 "+num2);
        // }
        // else if ( num3 > num1 && num3 > num2) {
        //     System.out.print("가장 큰 수는 "+num3);
        // }
        // 풀이법 2 - 최대값을 max라는 변수에 넣을거라서 미리 선언
        int max = 0;
        if (num1 > num2) {
            if (num1 > num3) {
                max = num1;
            } else {
                max = num3;
            }
        }
        else {
            if (num2 > num3) {
                max = num2;
            } else {
                max = num3;
            }
        }
        System.out.print("가장 큰 수는 "+ max);
    }
}
