import java.util.Scanner;

public class if_6 {
    public static void main(String[] args) {
        // 유저에게 대학교 학년(year), 점수(score) 인풋 받아서 처리 - 
        // 1~3학년은 60점 이상이면 합격 - 4학년은 70점 이상이어야
        // 대학교 학년이 4년을 넘거나 점수가 0점미만 100점 초과면
        // 범위를 초과했다는 메세지주고 나오기
        Scanner scanner = new Scanner(System.in);
		System.out.print("학년 입력: ");
		int year = scanner.nextInt();
		System.out.print("점수 입력: ");
		int score = scanner.nextInt();

		if (year >= 1 && year <= 4 && score >= 0 && score <= 100) {
			if (score >= 60) {
				if (year != 4) {
					// 1~3학년 합격
					System.out.println("합격");
				} else if (score >= 70) {
					// 4학년 합격
					System.out.println("합격");
				} else {
					// 위의 두 조건을 만족하지 않기 때문에 불합격
					System.out.println("불합격");
				}
			} else {
				System.out.println("불합격");
			}
		} else {
			System.out.println("점수, 학년 값이 입력 범위를 벗어났습니다.");
		}
    }
}
