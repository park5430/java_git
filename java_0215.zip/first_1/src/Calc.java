// 클래스+객체지향이 필요한 이유
// 덧셈 로직이 들어간 계산기 코드입니다. 
// 기업의 매출액 계산 프로그램이라 가정하시죠.
// 만약에 손익 계산이 필요한 기업이 5개 라면 어떻게 할까요?
// 같은 기능을 하는 클래스를 반복하지 않고 서로다른 객체에 넣어서
// 불필요한 반복을 피하고 코드의 재활용도를 높였습니다.
// 클래스 안에 기능 추가는 아래같이 간단합니다.
// sub이란 이름의 함수가 calculator1 클래스 안에 속해서 자유롭게 불러왔습니다.

class calculator1 {
    int result = 0;

    int add(int num) {
        result += num;
        return result;
    }
    int sub(int num) {
        result -= num;
        return result;
    }
}

public class Calc {
    public static void main(String[] args) {
        // 사전에 정의된 calculator1 이란 클래스를 
        // 5개의 다른 객체에 저장해서 중복된 클래스 지정을 막았음
        calculator1 cal1 = new calculator1();
        calculator1 cal2 = new calculator1();
        calculator1 cal3 = new calculator1();
        calculator1 cal4 = new calculator1();
        calculator1 cal5 = new calculator1();

        System.out.println(cal1.add(3));
        System.out.println(cal1.add(4));
        System.out.println(cal1.sub(2));

        // System.out.println(cal2.add(10));
        // System.out.println(cal2.add(11));

        // System.out.println(cal3.add(1));
        // System.out.println(cal3.add(3));

        // System.out.println(cal4.add(11));
        // System.out.println(cal4.add(33));

        // System.out.println(cal5.add(111));
        // System.out.println(cal5.add(333));
    }
}
