package array;

import java.util.Scanner;
public class array_4 {
    public static void main(String[] args) {
        // 1~10 사이의 배열 데이터 셋이 하나 주어졌을 때
        // 유저가 특정 데이터를 입력한 경우 
        // 그 숫자가 몇번 인덱스에 있는지 출력
        int[] num = { 5, 2, 1, 3, 4, 7, 6, 9, 10, 8 };
        // scanner & for문을 사용해서 어떻게 할 것인가?
        Scanner scan = new Scanner(System.in);
        System.out.print("1에서 10 사이의 정수를 입력해 주세요");
        int number = scan.nextInt();
// 만약에 유저가 규정된 값 밖의 수를 입력하면
// 제대로 넣을때까지 while문으로 가둬주세요 ㅋㅋㅋ
// while 문의 추가로 프로그램의 안정성 증가
while ( number > 10 || number < 0) {
    System.out.print("다시 입력해 주세요");
    // 새로운 입력값을 받아본다
    number = scan.nextInt();
}
        for (int i =0; i< num.length; i++) {
            // 입력받은 숫자를 전체 데이터셋과 
            // 하나하나 대조해 보는 시간 입니다.
            // 입력받은 숫자가 배열데이터 셋의 원소와 매치한다면
            if (number == num[i]) {
                // 아래 출력 메세지로 데이터가 있음을 확인함
         System.out.print(number+"는 " + i+" 번 인덱스에 있습니다");
            }
        }
    }
}
