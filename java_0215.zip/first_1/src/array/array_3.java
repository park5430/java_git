package array;

import java.util.Scanner;
public class array_3 {
    public static void main(String[] args) {
        // 크기가 3인 정수형 배열을 선언하고 실행했을때 값을 입력받아
        // 배열에 저장한 후 합계와 평균을 계산한다.
        // 입력값에 대한 새로운 객체생성 후 scanner에 저장
        Scanner scanner = new Scanner(System.in);
        // 크기가 3인 정수형 배열을 만들자.
        int[] numbers1 = new int[3];
        // 배열안의 개별 값을 입력받아 저장하자
        System.out.print("첫번째 값을 입력하세요");
        //입력받은 값을 배열의 첫째 요소에 저장한다.
        numbers1[0] = scanner.nextInt();
        System.out.print("두번째 값을 입력하세요");
        numbers1[1] = scanner.nextInt();
        System.out.print("세번째 값을 입력하세요");
        numbers1[2] = scanner.nextInt();
        // 만들어진 배열에 대한 합을 for문을 통해 구한다.
        // 합계를 받을 sum이란 변수를 선언한다
        int sum = 0;
        // for문 안에서 numbers1의 각 요소를 호출하여 sum변수 안에
        // 누적 합산을 진행한다
        for (int i = 0; i < numbers1.length; i++) {
            sum = sum + numbers1[i];
        }
        System.out.println(sum);
        System.out.println(sum/numbers1.length);
    }
}
