package array;


public class array_1 {
    public static void main(String[] args) {
        // 배열에 대한 설명: 하나의 변수가 여러개의 값을 가지는 변수
        // 크기가 5인(숫자가 다섯개 들어가는) 정수형배열 numbers1
        // 정수형 배열 선언 시, 기본값은 전부 0이다
        int[] numbers1 = new int[5];
        System.out.println("numbers1[0] = " + numbers1[0]);
        numbers1[0] = 100;
        System.out.println("numbers1[0] = " + numbers1[0]);
        // 배열의 크기 확인
        System.out.println(numbers1.length);
        // 얘는 왜 에러? 배열이 숫자 5개 있는데 6번째 숫자 요구 하니까...
        // System.out.println("numbers1[5] = " + numbers1[5]);
        // 크기가 3인 String 배열 strings1
        String[] strings1 = new String[3];
        // 문자열 배열은 기본값이 null이다
        System.out.println("strings1[0] = " + strings1[0]);
        // 정수형배열 numbers2 이름만 선언하고 
        // 다음 줄에 크기 8을 지정하여 배열 선언
        int[] numbers2 = null;
        numbers2 = new int[8];
        System.out.println("numbers2[0] = " + numbers2[0]);
        // 배열 선언할 때 안에 있는 개별 숫자도 전부 사전 지정할 때
        int[] numbers3 = {10, 20, 30, 40};
        // "가", "나", "다", "라"가 들어있는 strings2 배열 선언
        String[] strings2 = {"가", "나", "다", "라"};


    }
}
