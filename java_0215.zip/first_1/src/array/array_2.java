package array;
public class array_2 {
    public static void main(String[] args) {
    // 정수형 배열에 데이터를 넣는법
    // 어제 배운건 배열 길이를 지정하고 데이터를 넣었는데
    // 아래같았다...
    int[] number11 = null;
    number11 = new int[5];
    number11[0] = 10;
    number11[0] = 20;
    // 배열의 길이 지정 없이 데이터를 추가하면 한번에 가능
    int[] number1 = {10, 20, 30, 40, 50};
    int[] number2 = {10, 20, 30, 40};
    int[] number3 = {10, 20, 30, 40, 50, 60};
    // 일반적인 변수처럼 아래처럼 하면 에러난다. 취급주의
    // number1 = {10, 20, 30, 40, 50};
    // 배열 안의 원소값 출력
// 실무에선 반복문 안에 숫자쓰는걸 그닥 좋아하진 않는다.
// 하드코딩이라고 하는데 이는 데이터가 바뀌면 에러를 내기 때문
    // for (int i =0; i < number2.length; i++) {
    //     System.out.println(number2[i]);
    // }
// 배열안의 합계와 평균을 구해보자
// 합계 인생 하드모드
int kkk = number1[0] + number1[1] + number1[2] + number1[3] + number1[4];
// System.out.println(kkk);
// 배열 데이터길이가 5개가 아닌 50개라면? -> for문을 쓴다
int sum = 0;
for (int i =0; i < number1.length; i++) {
    sum = sum + number1[i];
}
// 이제 평균은 어떻게 구하는가?
System.out.println(sum/number1.length);
    }

}
