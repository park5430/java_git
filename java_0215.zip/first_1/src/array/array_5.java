package array;

import java.util.Scanner;
public class array_5 {
    public static void main(String[] args) {
        // 거스름돈 계산하기
        // 유저가 돈을 입력하면 예) 170입력 시 100 1개, 50 1개, 10 2개
        // 1. 거스름돈 데이터셋 준비 (모든 거스름돈 단위 준비)
        int[] coin = {500, 100, 50, 10};
        // 2. 유저에게 계산할 액수를 받아오기
        Scanner scanner = new Scanner(System.in);
        System.out.print("잔액을 입력해 주세요");
        int change = scanner.nextInt();
        // 3. 거스름 돈 액수 별로 개수 세기
        // for문을 사용하여 액수 별 거스름돈 개수를 파악한다
        // for 문 사용 전에 거스름돈 개수를 세는 변수를 미리 선언
        // int count = 0;
        // for (int i = 0; i < coin.length; i++) {
        //     // 해당 원소의 돈으로 잔액을 나눈다
        //     count = change / coin[i];
        //     System.out.print(coin[i]+"원 동전" + count+"개");
        //     // 동전으로 나누고 남은 값을 다음 계산에 활용한다
        //     change = change % coin[i];
        // }
        // 나눗셈 기호화 나머지 기호를 잘 구분하세요
        // 예) 900원을 500원으로 나누면 1.8인데
        // 정수형 자료형인 int에 둬서 소수점이 짤린다.
        // 이런 성질을 이용해서 나눗셈의 몫을 계산함
        // 900 / 500의 나머지는 400이니가 결과가 달라짐
            int rrr = change / coin[0];
            System.out.println(rrr);
            int rrr2 = change % coin[0];
            System.out.println(rrr2);

    }
}
