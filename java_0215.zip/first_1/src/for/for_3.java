public class for_3 {
    public static void main(String[] args) {
        // 어제 예제를 참고해서 for문을 써서
        // 1 ~ 10 까지의 숫자 합을 출력해 주세요
        // 이때, 1+2+3+4+5+6+7+8+9+10= 이렇게 나오게 해주세요
        // 만약에 1+2+3+4+5+6+7+8+9+10=55 라고 하고싶다면?
        int sum = 0;
        for (int i = 1; i <= 10; i++) {
            sum = sum + i;
            // 1에서 9까지 숫자랑 + 사인만 출력하도록 조건 설정
            if (i < 10) {
                System.out.print(i + "+");
            }
            // 마지막 경우의 수니까 else로 처리한다
            else {
                System.out.print(i + "=");
            }
        }
        // 최종 합 결과를 출력한다.
        System.out.print(sum);
}
}