public class for_5 {
    public static void main(String[] args) {
        // 1부터 100까지의 숫자 중에서 3의 배수만 출력하고 
        // 그리고 3의 배수에 대한 합계도 구하기
        int sum = 0;
        // 순차적으로 100까지 for문을 돌려보자
        for (int i = 1; i <= 100; i++) {
            // 3의 배수 조건을 만족하는 "경우"에만 결과출력 및 합 계산
            if (i % 3 == 0) {
                System.out.println("i = " + i);
                sum = sum + i;
            }
        }
        // 최종결과 출력
        System.out.println(sum);
    }
}
