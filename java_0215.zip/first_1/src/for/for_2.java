public class for_2 {
    public static void main(String[] args) {
        // 퀴즈

        // // 1 ~ 5 출력 예제를 보시고
        // for (int i = 1; i <= 5; i++) {
        //     System.out.println("i = " + i);
        // }

        // // 5, 4, 3, 2, 1을 출력해 보세요
        // for (int i = 5; i >= 1; i--) {
        //     // 아래에서 사용된 + 사인은 숫자를 더하는 연산자가 아닌 
        //     // 문자열 'i =' 글자 바로옆에 붙여서 쓰겠다는 의미.
        //     System.out.println("i = " + i);
        // }
        // // 해답 2
        // // 하던대로 1 ~ 5 를 만든 다음에 6에서 뺌으로서 5 ~ 1 결과만듬
        // int j = 6;
        // for (int i = 1; i <= 5; i++) {
        //     System.out.println("i = " + (j - i));
        // }

        // 2 4 6 8 10 출력
        for (int i = 1; i <= 5; i++) {
            System.out.println( i*2);
        }
        // i에다 1씩 더하라는 명령은 i++, i = i + 1, i += 1
        // 그러면 i에 2씩 더하려면?
        // i = i + 2, i += 2
        for (int i = 2; i <= 10; i+=2) {
            System.out.println( i);
        }

    }
}
