public class condition {
    public static void main(String[] args) {
        // 조건문 반복문은 자동화에 필수!!!!

        // if문: 조건에 따라 실행되는 구간을 다르게한다
        // 삼항 연산자 로직과 비교해 보시죠.
        // 동일한 로직입니다.
        int score = 85;
        char grade = (score > 90) ? 'A' : ((score > 80) ? 'B' : 'C');
        System.out.println(grade);

        if(score > 90) {
            System.out.println("A");
        }
        else if (score > 80) {
            System.out.println("B");
        }
        else {
            System.out.println("C");
        }
        // 주사위 결과 예제
        // 만약에 1 ~6 사이 무작위 정수를 만들고 싶다면?
        // 랜덤 주사위 결과는 어떻게?
        // hint: Math.random() 쓰면 0~1 사이 실수값 하나 나옴
        // 1. 6을 곱한다. 곱하면 0 ~ 5.99999 이런결과 나온다
        // 2. 여기에 int 씌워서 소수점 부분 버린다 -> 0~5사이 정수
        // 3. 1 더해서 원하는 1 ~ 6 사이 정수를 무작위로 뽑는다.
        int num = (int) (Math.random() *6) + 1;

        if (num == 1) {
            System.out.println("1");
        }
        else if (num == 2) {
            System.out.println("2");
        }
        else if (num == 3) {
            System.out.println("3");
        }
        else if (num == 4) {
            System.out.println("4");
        }
        else if (num == 5) {
            System.out.println("5");
        }
        else {
            System.out.println("6");
        }

    // if 문은 다 좋은데 코드가 뭔가 깔끔하지 못하다 (가독성)
    // 가독성을 보완한 switch 구문이 존재한다.
    // switch 구문은 가독성이 나은데, 정수결과만 지원!
        switch(num) {
            case 1:
            System.out.println("1");
            break;
            case 2:
            System.out.println("2");
            break;
            case 3:
            System.out.println("3");
            break;
            case 4:
            System.out.println("4");
            break;
            case 5:
            System.out.println("5");
            break;
            default:
            System.out.println("6");
        }

    }
}
