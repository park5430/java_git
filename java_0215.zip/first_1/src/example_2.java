public class example_2 {
    public static void main(String[] args) {
        // 비트논리 연산자 (여러가지 논리를 비교해서 판단)
        // and, or, XOR
        // 1. and 예시
        int aa = 8;
        if ((aa <= 10) && (aa <=99)) {
            System.out.println("조건1이 참입니다.");
        }
        
        // 2. or 예시
        if ((aa <= -10) || (aa <=-99)) {
            System.out.println("조건2가 참입니다.");
        }

        // 3. XOR 예시 (둘 중 하나는 참이고 하나는 거짓이어야함)
        if ((aa <= -10) ^ (aa <=99)) {
            System.out.println("조건3가 참입니다.");
        }

        // 비트 이동 연산자
        int result = 1 << 3;
        System.out.println(result);
        int result2 = -8 >> 3;
        System.out.println(result2);

        // 삼항 조건 연산자 (if문)
        int score = 85;
        // grade라는 변수는 학점입력기이다.
        // score 값이 90이 넘으면 A라고 출력하고
        // 90을 못넘으면 다시 80이 넘는지 본다음에 넘으면 B
        // 나머지는 c를 출력한다
        char grade = (score > 90) ? 'A' : ((score > 80) ? 'B' : 'C');
        System.out.println(grade);
    }
}
