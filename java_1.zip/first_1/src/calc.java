public class calc {
    public static void main(String[] args) {
        //여기서 부터 코드의 본문을 입력하시면 됩니다.
        // 자바언어의 특징은 문장이 끝날 때 마다 
        // 세미콜론을 붙여주시면 됩니다
        // 여기서 int의 뜻은 앞의 수가 integer 즉, 정수라는 이야기 
        byte x = 1;
        byte y = 2;
        int result = x + y;
        System.out.println(result);
    }
}
