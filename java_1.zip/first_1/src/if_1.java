public class if_1 {
    public static void main(String[] args) {
        // 부울 타입 변수로 "거짓"을 cond 변수에 저장함
        boolean cond = false;
        // 부울 타입의 변수가 "거짓"이므로 if절의 두번째 조건이 실행됨
        // ==의 뜻은 두 수가 같다이고요, !=의 뜻은 둘이 같지않다는 의미입니다.
        // 그러면 !cond 의 뜻은 어떻게 될까요? 거짓의반대는 "참"입니다
        if (!cond) {
            System.out.print("참인 친구만 눈에 보임");
        }
        else {
            System.out.print("거짓인 친구만 눈에 보임");
        }

        int num1 = 10, num2 = 10;
        // if절에서는 소괄호 부분이 참 거짓을 구분하는 파트가 된다
        if (num1 < num2) {
            System.out.print("num2가 더 크다");
        } else {
            System.out.print("num1이 num2보다 크거나 같다");
        }

        // 좀 더 세부적인 if & else if 문
        if (num1 < num2) {
            System.out.print("num2가 더 크다");
        }
        else if (num1 > num2) {
            System.out.print("num1가 더 크다");
        }
        else if (num1 == num2) {
            System.out.print("두 수가 같다");
        }
        else {
            System.out.print("뭐가 이상함. 비교 안됨");
        }
    }
}
