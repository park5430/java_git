public class for_8 {
    public static void main(String[] args) {
        // 4x + 5y = 60 을 만족하는 x, y 값을 출력
        // x, y는 1이상 10이하인 정수
        // 정답이 출력되도록 구하세요 ^^ (x=5, y=8) & (x=10, y=4)
        // 2중 for문을 통해서 x & y 의 100가지 모든 경우의 수를 대입하도록 한다.
        // 주의할 점은 for문에서 ;로 중간에 끊지 않아야 하고 괄호의 범위에 유의한다.
        // 특히 for문 안에 x & y 는 그 for문 안에서만 유효하니까 잘못 끊으면 
        // 설정한 변수가 없다고 거짓말한다 ^^
        for (int x = 1; x <= 10; x++) {
            for (int y = 1; y <= 10; y++) {
                // 2중 for 문 후에 아래의 방정식을 만족하는지 확인한다.
                if ((4 * x) + (5 * y) == 60) {
                    System.out.println("x: " + x + "  y: " + y);
                }
            }
        }
    }
}
