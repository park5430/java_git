public class string_1 {
    public static void main(String[] args) {
        // 자바의 변수는 일반타입과 참조타입이 있다.
        // 일반타입은 정수, 실수, 부울 문자열이 여기 해당하고
        // 참조타입은 문자열, 객체 등이 있다.
        // 참조타입은 값 자체가 아닌 값이 담긴 객체 메모리 주소를 참조한다
        // 일반적으로 같은 값을 가진 변수는 같은 메모리 주소를 공유하는데
        // new 라는 명령어로 새로운 "객체"를 만들면 다른 메모리 주소를 가진다.
        // 그래서 같은 값이 다르다고 말해버린다.
        // 그래서 참조타입에서 값이 같아도 객체가 다르면 다르다고 인식함
        String str1 = "안녕";
        String str2 = "안녕";
        String str3 = new String("안녕");
        // 세 변수는 모두 같아야 하는데 그렇지 않다.
        System.out.println(str1 == str2);
        System.out.println(str1 == str3);
        // 단, equals명령어는 값 자체만 비교시키는 명령어라서 같다고 함
        System.out.println(str1.equals(str3)); 
    }
}
