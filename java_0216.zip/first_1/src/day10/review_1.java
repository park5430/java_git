package day10;
 // 참 거짓 관련 비교연산자
// && and, || or (자바 스크립트와 동일), ^ XOR (자바종특)
// "돈이 3000원 이상있거나 카드가있다면 
// 택시를 타고 그렇지 않으면 걸어가라"
import java.util.ArrayList;
import java.util.Arrays;
public class review_1 {
    public static void main(String[] args) {
       int money = 6000;
       boolean hadCard = false;
       if (money >= 3000 ^ hadCard) {
        System.out.println("택 시 를 타 고 가 라");
       }
       else {
        System.out.println("걸어가라");
       }
// 그러면 문자열 데이터가 담긴 자료형은 어떻게 처리 하나요?
// String[] ppp = {"paper", "money", "creditcard"};
// 만약 ppp라는 데이터 셋에 "신용카드" 문자열이 있다면
// 택시타고 아니면 걸어가라 이렇게 말하고 싶다면?
// 즉 if문에서 문자열 배열 데이터를 처리하고 싶다면?
String[] ppp = {"paper", "money", "creditcard"};
// 리스트 자료구조로 문제 해결
// if (ppp[2] ="creditcard" ) {
//     System.out.println("택 시 를 타 고 가 라");
//    }
// 문자열 데이터가 담긴 리스트 자료구조를 ArrayList를 통해 생성
ArrayList<String> pocket = new ArrayList<String>();
// 원하는 데이터를 집어 넣는다.
pocket.add("paper");
pocket.add("money");
pocket.add("creditcard");

if (pocket.contains("creditcard")) {
    System.out.println("택 시 를 타 고 가 라");
}

// 별해: 문자열 배열을 가지고 문제를 해결 하려면?
// Arrays.asList(ppp)는 ppp를 리스트 자료구조로 변환하는 명령어
// 문자열 배열인 ppp를 리스트로 수동변환
if (Arrays.asList(ppp).contains("creditcard")) {
    System.out.println("택 시 를 타 고 가 라");
}
// if문의 조건이 정수면 switch를 쓰는게 좋다.
int xxx = 13;
String months = "";
switch (xxx) {
    case 1: months = "jan";
    break;
    case 2: months = "feb";
    break;
    case 3: months = "mar";
    break;
    default: months = "필요없음";
    break;
}
System.out.println(months);
// 나무를 10번 찍을때까지 while에 있다가 10번 되면 끝메세지 주기
int treehit = 0;
// while (treehit < 10) {
//     treehit++;
//     System.out.println("나무를 " + treehit + "번 찍으셨어요");
// }
// if (treehit == 10) {
//     System.out.println("나무가 넘어 갑니다");
// }
// for문으로 해결해 보기
// 둘다 일정 조건을 만족할 때까지 반복함
for (int i = 0; i <10; i++) {
    treehit++;
    System.out.println("나무를 " + treehit + "번 찍으셨어요");
}
if (treehit == 10) {
    System.out.println("나무가 넘어 갑니다");
}
// while문에서 break 사용하기
// 돈을 받고 커피를 계속 줍니다. 준비된 커피가 떨어지면 판매중지
int coffee = 10;
int money1 = 300;
while (money1 >0) {
    System.out.println("돈을 받았으니 커피를 줍니다");
    coffee--;
    money1 = money1 - 30;
    System.out.println("남은 커피는 " + coffee + "잔 입니다");
    if (coffee == 0) {
        System.out.println("커피가 다 떨어져서 판매중지!");
        //break;
    }
}
// for문으로 같은 예제를 풀어 주세요

for (int i =0; money1 >=30; i++) {
    System.out.println("돈을 받았으니 커피를 줍니다");
    coffee--;
    money1 = money1 - 30;
    System.out.println("남은 커피는 " + coffee + "잔 입니다");
    if (coffee == 0) {
        System.out.println("커피가 다 떨어져서 판매중지!");
        //break;
    }
}
// while문 안에서 특정 조건만 실행 하려면?
// 1.if써서 맞는 조건을 실행  2. continue써서 안맞는조건 제껴
// 1~10까지 수에서 짝수만 출력
int aa = 0;
while (aa <10) {
    aa++;
    if (aa % 2 ==0) {
        continue; // 짝수인 경우 while로 돌아간다
    }
    System.out.println(aa);
}

// 숫자 배열 데이터 예제
// {90, 25, 67, 45, 80} 5명 학생의 점수가 다음과 같다
// 60점 이상이면 xx번 학생 합격, 미만이면 불합격을 출력하세요
int [] marks = {90, 25, 67, 45, 80};
for (int i =0; i<marks.length; i++) {
    if ( marks[i] >= 60) {
        System.out.println((i+1)+"번 학생은 합격입니다");
    }
    else {
        System.out.println((i+1)+"번 학생은 불합격입니다");
    }
}
for (int i =0; i<marks.length; i++) {
    if ( marks[i] < 60) {
        //System.out.println((i+1)+"번 학생은 불합격입니다");
        continue; // 조건문으로 돌아갑니다
    }
    else {
        System.out.println((i+1)+"번 학생은 합격입니다");
    }
}

// for each 문에 대한 추가예제
String[] numbers = {"one", "two", "three"};
for (int i=0; i< numbers.length; i++) {
    System.out.println(numbers[i]);
}
// 여기에 number99는 i역할을 합니다
// 데이터 타입을 명시하고 각 데이터 셋 안의 데이터를 끄집어내요
// for each 쓰려면 데이터가 배열 아니면 리스트만 가능해요 
for (String jj: numbers) {
    System.out.println(jj);
}
// 같은 예제에 대해 리스트 데이터셋이면 어떻게 하나요?
ArrayList<String> numbers99 = 
new ArrayList<> (Arrays.asList("one1", "two2", "three3"));
for (String kkk: numbers99) {
    System.out.println(kkk);
}

// while문을 써서 1~1000까지 정수 중에 3의 배수의 합을 구하세요
// 웬만하면 continue써서 해보세요
int zzzz = 1;
int sum11 = 0;
while ( zzzz <= 1000) {

    if (zzzz % 3 !=0) {
        zzzz++;
        continue;
    }
    sum11 += zzzz;
    zzzz++;
}
System.out.println(sum11);
    }
}
