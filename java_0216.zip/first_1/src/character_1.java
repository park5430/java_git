public class character_1 {
    public static void main(String[] args) {
        // 문자열 데이터 출력 관련
        // 200 개 기업을 돌며 회계감사를 하는 회계사를 상상하자
        // 2024년 1분기 삼성전자 손익계산서 - 이런 제목을 상상하시죠
        // 회계사는 4분기 매 분기마다 200개 기업을 돕니다.
        // 2024년 1분기 lg전자 손익계산서
        // 2024년 1분기 cj cgv 손익계산서
        // 2024년 2분기 삼성전자 손익계산서
        // 문자열 데이터를 중간에 못고치니까 너무 힘들다. 방법이 없을까?
        // %d, %s 를 이용해서 각각 숫자 및 문자열 데이터를 변수화한다

        int quarter = 3;
        int quarter1 = 1;
        String company = "lg 전자";
        String company4 = "삼성전자";
        // 내가 원하는 내용을 데이터베이스 화 시켜서 반복문을 통해
        // 원하는 만큼 자동생성 가능 ^^
        System.out.printf("2024년 %d분기 %s 손익계산서\n", quarter, company);
        System.out.printf("2024년 %d분기 %s 손익계산서", quarter1, company4);
    }
}
