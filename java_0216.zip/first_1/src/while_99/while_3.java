public class while_3 {
    public static void main(String[] args) {
        // random() 메서드를 이용해서 1~6이 나오는 주사위를 설정하고
        // 주사위가 계속 던져지면서 6이 나오면 종료되는 코드 작성
        // 힌트는 int num = (int) Math.random() * ?? ??
        boolean run = true;
        while (run) {
            int num = (int) (Math.random() * 6) +1;
            System.out.println("num = " + num);
            // 주사위를 계속 굴리다가 6이 나오면
            // 부울변수의 값을 false로 바꿔서 while문 탈출
            if ( num ==6) {
                run = false;
            }
        }
        System.out.println("이제 빠져나왔군 ^^");
    }
}
