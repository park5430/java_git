package switch_99;

public class switch_1 {
    public static void main(String[] args) {
        // switch는 일반적으로 정수인 경우에 그 정수에 해당하는 케이스로 빠지는 로직입니다
        int num = 6;
        switch (num) {
            case 0: // num == 0
                System.out.println("num은 0입니다.");
                break;
            case 1: // num == 1
                System.out.println("num은 1입니다.");
                break;
            case 2:
                System.out.println("num은 2입니다.");
                break;
            default:
                System.out.println("1,2,3이 아닙니다.");
                break;
        }

        // switch 케이스는 문자열로도 사용 가능합니다
        String city = "인천";
        switch (city) {
            case "서울":
            System.out.println("서울입니다");
            break;
            case "인천":
            System.out.println("인천입니다");
            break;
            case "강릉":
            System.out.println("강릉입니다");
            break;
            default:
            System.out.println("한국이 아닐수도");
            break;
        }
    }
}
