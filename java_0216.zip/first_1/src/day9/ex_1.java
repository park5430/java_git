package day9;
// Scanner, List, 정렬, 해시맵은 import 필요
import java.util.ArrayList;
import java.util.Arrays;
// 오름차순 혹은 내림차순 정렬에 필요
import java.util.Comparator;

import java.util.HashMap;

public class ex_1 {
    public static void main(String[] args) {
        // 국어 영어 수학 점수가 각각 80, 75, 55점인데
        // 국영수의 평균을 구해주세요
        int a = 80, b = 75, c = 55;
        System.out.println((a+b+c)/3);
        // 리스트 자료형을 선언하고 1,3,5,4,2를 집어넣으세요
        // 그리고 그 집어넣은 리스트 자료형을 5,4,3,2,1로 정렬
        ArrayList<Integer> myList = 
        new ArrayList<>(Arrays.asList(1,3,5,4,2));
        myList.sort(Comparator.reverseOrder()); // sort 관련 명령으로 정렬함
        System.out.println(myList);
        // 학점 등급과 점수가 담긴 해시맵 자료구조 선언
        // (A, 90), (B, 80), (C, 70) 데이터를 추가하여
        // B학점에 해당하는 데이터를 삭제하고 남은 값을 출력 
        HashMap<String, Integer> grade = new HashMap<>(); 
        grade.put("A", 90);
        grade.put("B", 80);
        grade.put("C", 70);
        grade.remove("B");
        System.out.println(grade);
    }
}
