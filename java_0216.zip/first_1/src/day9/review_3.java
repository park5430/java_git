package day9;
// 집합형 자료구조는 순서를 따지지 않는다. 비순서형 자료구조
// 비순서형 자료구조는 인덱싱 불가, 중복 데이터 불가
import java.util.Arrays;
import java.util.HashSet;

public class review_3 {
    public static void main(String[] args) {
        // HashSet을 이용하여 set(집합) 자료형을 선언하였다.
        // Arrays.asList를 이용하여 집합 내 개별 원소를 선언
        HashSet<String> set = new HashSet<>
        (Arrays.asList("h","e","l","l","o"));
        System.out.println(set);
        // 순서도 무시하고 l도 1개 빠짐 (중복 허용안됨)
        // 집합에서 교집합 차집합 여집합 하겠습니다.
        HashSet<Integer> s1 = new HashSet<>
        (Arrays.asList(1,2,3,4,5,6));
        HashSet<Integer> s2 = new HashSet<>
        (Arrays.asList(4,5,6,7,8,9));
        // 교집합이라면 4,5,6 이 출력됨
        // 집합 s1을 기준으로 교집합 준비
        HashSet<Integer> intersection = new HashSet<>(s1);
        intersection.retainAll(s2); // 교집합 수행
        System.out.println(intersection);
        // 합집합 하면 1,2,3,4,5,6,7,8,9
        HashSet<Integer> union = new HashSet<>(s1);
        union.addAll(s2); // 합집합 수행
        System.out.println(union);
        // s1을 기준으로 차집합을 수행하면 1,2,3
        // HashSet<Integer> subtract = new HashSet<>(s1);
        // subtract.removeAll(s2); // 차집합 수행
        // System.out.println(subtract);
        // s2를 기준으로 차집합을 수행하면
        HashSet<Integer> subtract = new HashSet<>(s2);
        subtract.removeAll(s1); // 차집합 수행
        System.out.println(subtract); 

        // 자료형 변환
        String num1 = "123";
        // 문자열을 정수로 바꾸려면 Integer 클래스사용
        int ss = Integer.parseInt(num1);
        System.out.println(ss);
        // 정수를 문자열로 바꾸려면 "" + 숫자변수
        int num2 = 1234;
        // String sss = String.valueOf(num2);
        String sss = "" + num2;
        System.out.println(sss);
        System.out.println((""+ss)+num2);
        System.out.println(""+(ss+num2));
        // 소수점이 있는 문자열 실수를 숫자로
        String num = "123.456";
        double dd = Double.parseDouble(num);
        // 실제로 숫자로 변환되었는지 덧셈으로 확인
        System.out.println(dd + 3.333);
    }   
}
