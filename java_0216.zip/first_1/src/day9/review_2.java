package day9;
// Scanner, List, 정렬, 해시맵은 import 필요
import java.util.ArrayList;
// 오름차순 혹은 내림차순 정렬에 필요
import java.util.Comparator;
// 해시맵 자료형을 쓸 때도 import 필요
import java.util.HashMap;

public class review_2 {
    public static void main(String[] args) {
        // pitches라는 이름으로 새로운 객체형성
        ArrayList pitches = new ArrayList();
        // 원하는 만큼 데이터 입력
        pitches.add("138");
        pitches.add("129");
        pitches.add("142");
        // 데이터 입력 후 리스트안에 두번째 데이터를 출력함
        System.out.println(pitches.get(1));
        // 리스트 데이터의 크기는 size로 처리함
        System.out.println(pitches.size());
        // 리스트 내 특정 데이터 존재여부는 contains로 판단
        System.out.println(pitches.contains("142"));
        // 리스트 내 데이터의 삭제는 remove사용 삭제후에 true false리턴
        System.out.println(pitches.remove("29"));
        System.out.println(pitches.contains("129"));
        // 그러면 데이터의 정렬은 어떻게? 오름차순으로 정렬
        pitches.sort(Comparator.naturalOrder());
        System.out.println(pitches);
        // 그러면 데이터의 정렬은 어떻게? 내림차순으로 정렬
        pitches.sort(Comparator.reverseOrder());
        System.out.println(pitches);
        // 맵 자료형의 소개
        // 맵 자료형이란 이름=홍길동, 사는곳=구월동 등으로 
        // 데이터의 대응관계를 나타내는 자료형이다
        // 이름과 사는곳은 데이터의 키(key)값이고 
        // 홍길동과 구월동은 데이터의 값(value)이다
        // 맵자료형은 순차적으로 값을 찾지않고 key값을 이용해 데이터를 찾는다.
        // HashMap, LinkedHashMap, TreeMap등이 있는데 가장 기본은 HashMap이다.
        HashMap<Object, Object> map = new HashMap<>();
        // HashMap에 자료는 넣는 명령은 put입니다
        map.put("people", 8);
        map.put("baseball", 666666);
        System.out.println(map.get("people"));
        // HashMap<String, String> map = new HashMap<>();
        // 정말 문자열 데이터만 넣어야지 숫자 넣으면에러
        // 그러면 숫자 데이터 넣고 싶으면????
        // HashMap<Object, Object> map = new HashMap<>();
        
    }
}
