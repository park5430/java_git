package day9;

public class review_4 {
    public static void main(String[] args) {
        // if문은 참 거짓을 판단하여 참인 경우과 
        // 거짓인 경우로 나뉨 거짓에 대한 조건은 else
        // if문 안에는 부울 변수로 하드코딩 방지
        int pocket = 121000;
        int lunch = 119000;
        boolean xx = (pocket - lunch) > 6000;
        boolean yy = (pocket - lunch) > 1000;
        if (xx) {
            System.out.println("택시를 타자");
        }
        else if (yy) {
            System.out.println("버스를 타자");
        }
        else {
            System.out.println("걷는 걸로");
        }
        // != 같지않다 & (이상, 이하)같은 부등호수식은 부등호 먼저 >=, <=
        int x = 3, y = 2;
        System.out.println(x!=y);
    }
}
