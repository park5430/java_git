// 하위 폴더를 위치를 표시
// src 아래 하위폴더에 파일이 있는데 package로 명시안되면 에러남
package day9;
import java.util.Scanner;
// 1. 자바 파일 내부 살피기

// 자바 가장 바깥쪽 영역을 클래스 블록이라 합니다. 중괄호로 둘러싼다.
// public의 의미는 자바의 접근제어자라고 하는데 어디서든 이 클래스에 접근 가능합니다.
public class review_1 {
    // 메서드 블록이라 하고 중괄호로 구분 합니다.
    // 메서드란 클래스 안에 함수이고 함수라 하면 어떤 동작을 나타냅니다.
    public static void main(String[] args) {
        // 메서드 블록 안에 명령문이 존재한다.
        // 컴퓨터에 뭔가를 시키는 문장을 명령문이라 한다.
        System.out.println("자바입니다");
        // 변수이름 쓸 때 숫자로 시작하면 안되고 특수문자도 안된다.
        // int 1st = 5;
        // int a# = 999;
        // for, if, import, long, short 같은 사전에 정의된 단어도 변수로 못쓴다.
        // 아래같은 경우를 예약어라고 한다
        // int for = 99;
        // 변수를 선언하고 나서는 변수 타입은 입력하면 안된다.
        // 최초에 88로 초기값을 선언한 다음에 
        // 사용자 인풋을 받아서 다른수를 넣는 예시
        int kkk = 88;
        Scanner scanner = new Scanner(System.in);
        System.out.println("1번째 숫자를 입력하세요");
        // 여기에 int 달면 변수의 중복선언으로 생각하여 오류를 일으킴
        kkk = scanner.nextInt();
        System.out.println(kkk);
        // 변수 이름을 짓는 국룰
        // 1. 클래스 이름 지을때는 명사로 해야하고 대문자로 시작
        // class Cookie {}
        // class Calculator {}
        // 2. 메서드 이름 지을때는 소문자로 시작합니다
        // 두개의 단어를 합친 이름일때는 두번째 단어 첫글자가 대문자
        // runFast();
        // getResult();

        // 연산자
        // % 나눗셈의 나머지 계산 주의하자 (배수 계산)
        // 정수형 자료형에서 나누면 나머지가 버려지니까 몫이 계산되는 효과가있다.
        System.out.println(7 % 3); // 몫이 2 나머지가 1. 그래서 1
        System.out.println(3 % 7); // 나머지가 그 수 전체 그래서 3

        //증감 연산자 ++, --
        int i = 0;
        // ++i 증가시키고 나서 값을 읽음
        // i++ 값을 읽고나서 증가시킴
        System.out.println(i++); // 출력은 0으로 하는데 i는 1로 바껴있다
        System.out.println(++i); // 1인친구를 1더해서 2만들고 나서 출력 그래서2
        // for (i=0; i<4; i++) // 그래서 for문의 i++는 항상이럼


        // 불자료형 변수값을 수식자체를 써도 됨(while문 조건 통제에 자주 쓰임)
        int p = 3;
        boolean isOdd = (p % 2 == 1);
        System.out.println(isOdd);
        // 객체는 값 자체 비교가 아닌 값의 메모리주소를 비교한다.
        // 새로운 객체를 생성하면 같은 값이지만 다른 메모리주소에 배정함
        // 첫째 방식을 리터럴 표기라고합니다.
        // 리터럴 표기란 고정된 값을 그대로 대입한다는 말입니다.
        String a = "hello";
        String b = new String("hello");
        System.out.println(a == b);

        // 문자열 내장 메서드 (자바내장 함수모음)
        // 값 자체만을 비교한다. 조건문할때 써야함
        System.out.println(a.equals(b));
        String c = "안녕하세요 삼성전자";
        String d = "hello Java";
        // indexOf는 문자열에서 특정단어 시작위치를 파악함
        System.out.println(c.indexOf("삼성전자"));
        // contains는 특정 문자열 포함여부 확인 true, false로 나옴
        System.out.println(c.contains("삼성전자"));
        // charAt 은 특정위치의 문자를 리턴함 (인풋엔 숫자)
        System.out.println(c.charAt(7));
        // replaceAll 은 특정 문자열을 다른 문자열로 바꿈
        System.out.println(c.replaceAll("삼성전자", "LG전자"));
        // toUpperCase 문자열은 전부 대문자로 변환
        // 이메일 기반 로그인이나 url 같이 대소문자 구분없는 친구를 검증할때
        // 인풋값을 변환하는 기능으로 사용한다.
        System.out.println(d.toUpperCase());
        // 문자열 포매팅
        // "삼성전자의 2023년 1분기 손익은 3조입니다"
        // 내가 200개 기업을 분기마다 회계감사다니는 회계사라면?
        // 보고서에 기업명, 분기, 손익숫자만 바꿔서 사용하려 들 것이다
        String f = "삼성전자의 2023년 1분기 손익은 3조입니다";
        System.out.println(String.format("삼성전자의 2023년 1분기 손익은 %d조입니다", 5));
        // 정수는 %d, 문자열은 %s 로 두고 문자열 포매팅을 사용하자 %c 문자1개짜리 %f 는 실수

        // 만약에 바꿀곳이 2군데 이상이면서 변수처리를 하고 싶다면????
        int profit1 = 2;
        String compName = "두산지주";
        System.out.println(String.format("%s의 2023년 1분기 손익은 %d조입니다", compName, profit1));
        // 배열 출력하려면 인덱스 명시 해야함
        int[] odds = {1,3,5,7,9};
        String[] weeks = {"월", "화", "수", "목", "금", "토", "일"};
        System.out.println(odds[2]);
        System.out.println(weeks[2]);
        // 배열안에 원소를 출력하려면 인덱스를 써야하니 for문처리
        for (int ii =0; ii<weeks.length; ii++) {
            System.out.println(weeks[ii]);
        }
        // 리스트 자료형을 소개합니다.
        // 배열과 같이 한 변수에 여러값이 들어가는데 수의 크기가 변합니다
        // 배열은 한번 선언하면 배열의 개수가 안바뀌니까 배열대비 편합니다
        // 리스트 자료형은 ArrayList를 일반적으로 쓴다
    }
    }

// 한 클래스 안에는 여러 메서드 블록 존재 가능하다.
// 한 메서드 블록 아래 여러 명령문이 존재한다.
// 한 파일 안에 여러 클래스를 만들 수 있지만, 보통 한 파일엔 클래스 하나만 만든다.


