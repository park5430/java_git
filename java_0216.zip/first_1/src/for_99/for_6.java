public class for_6 {
    public static void main(String[] args) {
        // 2중 for 문을 알아봅시다

        // 바깥 for문
        for (int i = 1; i <= 2; i++) {
            // 안쪽 for 문
            for ( int j = 1; j <=3; j++) {
                System.out.println("i값은" +i);
                System.out.println("j값은" +j);
            }
            System.out.println("안쪽for문 종료");
        }
        System.out.println("바깥쪽for문 종료");
    }
}
