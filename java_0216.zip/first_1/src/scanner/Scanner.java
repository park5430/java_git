
public class Scanner {

}
