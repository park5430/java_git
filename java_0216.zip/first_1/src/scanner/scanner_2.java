package scanner;

import java.util.Scanner;

public class scanner_2 {
    public static void main(String[] args) {
        // 문제를 드리려고 합니다.
        // Scanner 예제를 자세히 보시고요
        // 정수 2개를 각각 스캐너로 num1, num2에 입력받아서
        // 입력받은 수의 합을 출력하세요. ㅎㅎㅎ
        // 시스템에서 입력받은 값을 scanner변수에 저장
        Scanner scanner = new Scanner(System.in);
        // 첫번째 숫자 달라고 말하기
        System.out.println("1번째 숫자를 입력하세요");
        // 사용자가 입력한 숫자를 받아서 num1변수에 저장
        int num1 = scanner.nextInt();
        // 두번째 숫자 달라고 말하기
        System.out.println("2번째 숫자를 입력하세요");
        // 사용자가 입력한 두번째 숫자를 받아서 num2변수에 저장
        int num2 = scanner.nextInt();
        // 두 수의 값을 더해서 sum변수에 저장
        int sum = num1 + num2;
        System.out.println(sum);

        // 참고사항: 각 숫자 타입마다 next뒤에 숫자 타입이 붙는다
        // 알맞는 숫자 타입을 next바로뒤에 붙여주면 된다
        // nextShort, nextInt, nextLong, nextFloat. nextDouble

        // 그러면 next와 nextLine의 차이는?????
        // next를 써서 "자바를 배운다"고 입력하면 "자바를" 까지만 저장된다 
        // next는 공백 단위로 입력을 받기 때문이다
        // 반면 nextLine으로 쓰면 "자바를 배운다" 그대로 저장된다
        // nextLine은 엔터키 단위로 데이터 입력을 받기 때문

    }
}
