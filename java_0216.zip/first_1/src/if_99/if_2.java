import java.util.Scanner;

public class if_2 {
    public static void main(String[] args) {
        // 유저에게 자바 성적 인풋값을 받아서 60점 이상이면 합격
        // 미만이면 불합격이라 출력해 주세요
		Scanner scanner = new Scanner(System.in);
		System.out.print("점수를 입력하세요: ");
        int score = scanner.nextInt();
        if (score >=60) {
            System.out.print("합격 ");
        }
        else {
            System.out.print("불합격 ");
        }


    }
}
